/*	This program requires databaseConnection.java and SendEmail.java
 */

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginOTP
 */
@WebServlet("/LoginOTP")
public class LoginOTP extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String receivedOTP = request.getParameter("OTP");
		System.out.println("got it "+receivedOTP);
		if(receivedOTP.compareTo("sendOTP")==0)
		{
			//generate OTP
			String strOTP="";  
			for(int i=1;i<=4;i++)
			{	double doubleOTP = new Random().nextDouble();
				int intOTP = (int)(doubleOTP*10);
				strOTP=strOTP+intOTP;
			}
			
			// store in DB
			databaseConnection.insertOTP("OTPdetails",email,strOTP);
			
			// strOTP is generated OTP
			// send it for verification
			SendEmail.send("123tmails@gmail.com", "12345pass",email,"OTP",
					"Your OTP is "+strOTP+"."); 
			
			System.out.println("sent mail");
		}else {
			/// get OTP from database and compare
			System.out.println("in check");
			String getOTP=databaseConnection.selectOTP("OTPdetails",email);
			if(getOTP.compareTo(receivedOTP)==0)
			{	System.out.println("CORRECT");
				response.addHeader("OPTstatus","RIGHT");
			}else {
				System.out.println("WRONG");
				response.addHeader("OPTstatus","WRONG");
			}
			
		}
	}

}
